-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: happy_house
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `subject` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` varchar(2000) NOT NULL,
  `reg_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `hit` int NOT NULL DEFAULT '0',
  `state` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_user_id_user_idx_idx` (`user_id`),
  CONSTRAINT `fk_user_board` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary view structure for view `board_view`
--

DROP TABLE IF EXISTS `board_view`;
/*!50001 DROP VIEW IF EXISTS `board_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `board_view` AS SELECT
 1 AS `id`,
 1 AS `userId`,
 1 AS `nickName`,
 1 AS `subject`,
 1 AS `title`,
 1 AS `content`,
 1 AS `regDate`,
 1 AS `hit`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `chart_area_year_avg`
--

DROP TABLE IF EXISTS `chart_area_year_avg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chart_area_year_avg` (
  `sido_name` varchar(20) NOT NULL,
  `deal_year` int NOT NULL,
  `deal_amount` varchar(45) NOT NULL,
  PRIMARY KEY (`sido_name`,`deal_year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `board_id` int NOT NULL,
  `user_id` int NOT NULL,
  `content` varchar(200) NOT NULL,
  `reg_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `state` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_board_comment_idx` (`board_id`),
  KEY `fk_user_comment_idx` (`user_id`),
  CONSTRAINT `fk_board_comment` FOREIGN KEY (`board_id`) REFERENCES `board` (`id`),
  CONSTRAINT `fk_user_comment` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary view structure for view `comment_view`
--

DROP TABLE IF EXISTS `comment_view`;
/*!50001 DROP VIEW IF EXISTS `comment_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `comment_view` AS SELECT
 1 AS `id`,
 1 AS `boardId`,
 1 AS `userId`,
 1 AS `nickName`,
 1 AS `content`,
 1 AS `regDate`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `dongcode`
--

DROP TABLE IF EXISTS `dongcode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dongcode` (
  `dong_code` varchar(10) NOT NULL,
  `sido_name` varchar(30) DEFAULT NULL,
  `gugun_name` varchar(30) DEFAULT NULL,
  `dong_name` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`dong_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `housedeal`
--

DROP TABLE IF EXISTS `housedeal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `housedeal` (
  `no` bigint NOT NULL,
  `deal_amount` varchar(20) DEFAULT NULL,
  `deal_year` int DEFAULT NULL,
  `deal_month` int DEFAULT NULL,
  `deal_day` int DEFAULT NULL,
  `area` varchar(20) DEFAULT NULL,
  `floor` varchar(4) DEFAULT NULL,
  `cancel_deal_type` varchar(1) DEFAULT NULL,
  `apt_code` bigint DEFAULT NULL,
  PRIMARY KEY (`no`),
  KEY `index` (`apt_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `houseinfo`
--

DROP TABLE IF EXISTS `houseinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `houseinfo` (
  `apt_code` bigint NOT NULL,
  `build_year` int DEFAULT NULL,
  `road_name` varchar(40) DEFAULT NULL,
  `road_name_bonbun` varchar(5) DEFAULT NULL,
  `road_name_bubun` varchar(5) DEFAULT NULL,
  `road_name_seq` varchar(2) DEFAULT NULL,
  `road_name_basement_code` varchar(1) DEFAULT NULL,
  `road_name_code` varchar(7) DEFAULT NULL,
  `dong` varchar(40) DEFAULT NULL,
  `bonbun` varchar(4) DEFAULT NULL,
  `bubun` varchar(4) DEFAULT NULL,
  `sigungu_code` varchar(5) DEFAULT NULL,
  `eub_myun_dong_code` varchar(5) DEFAULT NULL,
  `dong_code` varchar(10) DEFAULT NULL,
  `land_code` varchar(1) DEFAULT NULL,
  `apartment_name` varchar(40) DEFAULT NULL,
  `jibun` varchar(10) DEFAULT NULL,
  `lng` varchar(30) DEFAULT NULL,
  `lat` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`apt_code`),
  UNIQUE KEY `UNIQUE` (`build_year`,`apartment_name`,`jibun`,`sigungu_code`,`eub_myun_dong_code`) /*!80000 INVISIBLE */,
  KEY `houseinfo_dongCode_dongcode_dongCode_fk_idx` (`dong_code`) /*!80000 INVISIBLE */,
  CONSTRAINT `houseinfo_dongCode_dongcode_dongCode_fk` FOREIGN KEY (`dong_code`) REFERENCES `dongcode` (`dong_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `interest`
--

DROP TABLE IF EXISTS `interest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `interest` (
  `user_id` int NOT NULL,
  `dong_code` varchar(10) NOT NULL,
  `sido_name` varchar(45) NOT NULL,
  `gugun_name` varchar(45) NOT NULL,
  `reg_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`,`dong_code`),
  KEY `fk_user_interest_idx` (`user_id`),
  KEY `fk_dongcode_interest_idx` (`dong_code`),
  CONSTRAINT `fk_dongcode_interest` FOREIGN KEY (`dong_code`) REFERENCES `dongcode` (`dong_code`),
  CONSTRAINT `fk_user_interest` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `interestapt`
--

DROP TABLE IF EXISTS `interestapt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `interestapt` (
  `user_id` int NOT NULL,
  `apt_code` bigint NOT NULL,
  `reg_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`,`apt_code`),
  KEY `fk_houseinfo_interestapt_idx` (`apt_code`),
  CONSTRAINT `fk_houseinfo_interestapt` FOREIGN KEY (`apt_code`) REFERENCES `houseinfo` (`apt_code`),
  CONSTRAINT `fk_user_interestapt` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary view structure for view `latlng_view`
--

DROP TABLE IF EXISTS `latlng_view`;
/*!50001 DROP VIEW IF EXISTS `latlng_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `latlng_view` AS SELECT
 1 AS `dongCode`,
 1 AS `sidoName`,
 1 AS `gugunName`,
 1 AS `count`,
 1 AS `lat`,
 1 AS `lng`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `like_view`
--

DROP TABLE IF EXISTS `like_view`;
/*!50001 DROP VIEW IF EXISTS `like_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `like_view` AS SELECT
 1 AS `boardId`,
 1 AS `userId`,
 1 AS `nickName`,
 1 AS `subject`,
 1 AS `title`,
 1 AS `regDate`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `likeboard`
--

DROP TABLE IF EXISTS `likeboard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `likeboard` (
  `board_id` int NOT NULL,
  `user_id` int NOT NULL,
  `reg_Date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`board_id`,`user_id`),
  KEY `fk_user_likeboard_idx` (`user_id`),
  CONSTRAINT `fk_board_likeboard` FOREIGN KEY (`board_id`) REFERENCES `board` (`id`),
  CONSTRAINT `fk_user_likeboard` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notice`
--

DROP TABLE IF EXISTS `notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` varchar(2000) NOT NULL,
  `reg_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `state` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_user_id_user_idx_idx` (`user_id`),
  CONSTRAINT `fk_user_board0` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary view structure for view `notice_view`
--

DROP TABLE IF EXISTS `notice_view`;
/*!50001 DROP VIEW IF EXISTS `notice_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `notice_view` AS SELECT
 1 AS `id`,
 1 AS `userId`,
 1 AS `title`,
 1 AS `content`,
 1 AS `regDate`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `qna`
--

DROP TABLE IF EXISTS `qna`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `qna` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `title` varchar(200) NOT NULL,
  `content` varchar(2000) NOT NULL,
  `reg_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `state` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary view structure for view `qna_view`
--

DROP TABLE IF EXISTS `qna_view`;
/*!50001 DROP VIEW IF EXISTS `qna_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `qna_view` AS SELECT
 1 AS `id`,
 1 AS `userName`,
 1 AS `password`,
 1 AS `title`,
 1 AS `content`,
 1 AS `regDate`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `qnacomment`
--

DROP TABLE IF EXISTS `qnacomment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `qnacomment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `qna_id` int NOT NULL,
  `user_id` int NOT NULL,
  `content` varchar(300) NOT NULL,
  `reg_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `state` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_qna_qnacomment_idx` (`qna_id`),
  KEY `fk_user_qnacomment_idx` (`user_id`),
  CONSTRAINT `fk_qna_qnacomment` FOREIGN KEY (`qna_id`) REFERENCES `qna` (`id`),
  CONSTRAINT `fk_user_qnacomment` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary view structure for view `qnacomment_view`
--

DROP TABLE IF EXISTS `qnacomment_view`;
/*!50001 DROP VIEW IF EXISTS `qnacomment_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `qnacomment_view` AS SELECT
 1 AS `id`,
 1 AS `qnaId`,
 1 AS `content`,
 1 AS `regDate`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `subject_view`
--

DROP TABLE IF EXISTS `subject_view`;
/*!50001 DROP VIEW IF EXISTS `subject_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `subject_view` AS SELECT
 1 AS `id`,
 1 AS `sidoName`,
 1 AS `gugunName`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(45) DEFAULT NULL,
  `password` varchar(100) NOT NULL,
  `nick_name` varchar(45) NOT NULL,
  `reg_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `location` varchar(45) NOT NULL DEFAULT '9999999999',
  `grade` int NOT NULL DEFAULT '0',
  `oauth` varchar(400) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nick_name_UNIQUE` (`nick_name`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  UNIQUE KEY `oauth_UNIQUE` (`oauth`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Final view structure for view `board_view`
--

/*!50001 DROP VIEW IF EXISTS `board_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `board_view` AS select `board`.`id` AS `id`,`board`.`user_id` AS `userId`,`user`.`nick_name` AS `nickName`,`board`.`subject` AS `subject`,`board`.`title` AS `title`,`board`.`content` AS `content`,`board`.`reg_date` AS `regDate`,`board`.`hit` AS `hit` from (`board` left join `user` on((`board`.`user_id` = `user`.`id`))) where (`board`.`state` = 0) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `comment_view`
--

/*!50001 DROP VIEW IF EXISTS `comment_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `comment_view` AS select `comment`.`id` AS `id`,`comment`.`board_id` AS `boardId`,`comment`.`user_id` AS `userId`,`user`.`nick_name` AS `nickName`,`comment`.`content` AS `content`,`comment`.`reg_date` AS `regDate` from (`comment` left join `user` on((`comment`.`user_id` = `user`.`id`))) where (`comment`.`state` = 0) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `latlng_view`
--

/*!50001 DROP VIEW IF EXISTS `latlng_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `latlng_view` AS select concat(left(`h`.`dong_code`,5),'00000') AS `dongCode`,`d`.`sido_name` AS `sidoName`,`d`.`gugun_name` AS `gugunName`,count(0) AS `count`,`h`.`lat` AS `lat`,`h`.`lng` AS `lng` from (`houseinfo` `h` join `dongcode` `d` on((`h`.`dong_code` = `d`.`dong_code`))) group by left(`h`.`dong_code`,5) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `like_view`
--

/*!50001 DROP VIEW IF EXISTS `like_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `like_view` AS select `likeboard`.`board_id` AS `boardId`,`likeboard`.`user_id` AS `userId`,`user`.`nick_name` AS `nickName`,`board`.`subject` AS `subject`,`board`.`title` AS `title`,`likeboard`.`reg_Date` AS `regDate` from (`likeboard` left join (`board` left join `user` on((`board`.`user_id` = `user`.`id`))) on((`likeboard`.`board_id` = `board`.`id`))) where (`board`.`state` <> -(1)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `notice_view`
--

/*!50001 DROP VIEW IF EXISTS `notice_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ssafy`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `notice_view` AS select `notice`.`id` AS `id`,`notice`.`user_id` AS `userId`,`notice`.`title` AS `title`,`notice`.`content` AS `content`,`notice`.`reg_date` AS `regDate` from `notice` where (`notice`.`state` = 0) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `qna_view`
--

/*!50001 DROP VIEW IF EXISTS `qna_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `qna_view` AS select `qna`.`id` AS `id`,`qna`.`username` AS `userName`,`qna`.`password` AS `password`,`qna`.`title` AS `title`,`qna`.`content` AS `content`,`qna`.`reg_date` AS `regDate` from `qna` where (`qna`.`state` = 0) order by `qna`.`id` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `qnacomment_view`
--

/*!50001 DROP VIEW IF EXISTS `qnacomment_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `qnacomment_view` AS select `qnacomment`.`id` AS `id`,`qnacomment`.`qna_id` AS `qnaId`,`qnacomment`.`content` AS `content`,`qnacomment`.`reg_date` AS `regDate` from `qnacomment` where (`qnacomment`.`state` = 0) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `subject_view`
--

/*!50001 DROP VIEW IF EXISTS `subject_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `subject_view` AS select distinct (case when (`dongcode`.`sido_name` like '서울특별시') then 1 when (`dongcode`.`sido_name` like '부산광역시') then 2 when (`dongcode`.`sido_name` like '대구광역시') then 3 when (`dongcode`.`sido_name` like '인천광역시') then 4 when (`dongcode`.`sido_name` like '광주광역시') then 5 when (`dongcode`.`sido_name` like '대전광역시') then 6 when (`dongcode`.`sido_name` like '울산광역시') then 7 when (`dongcode`.`sido_name` like '세종특별자치시') then 8 when (`dongcode`.`sido_name` like '경기도') then 9 when (`dongcode`.`sido_name` like '강원도') then 10 when (`dongcode`.`sido_name` like '충청북도') then 11 when (`dongcode`.`sido_name` like '충청남도') then 12 when (`dongcode`.`sido_name` like '전라북도') then 13 when (`dongcode`.`sido_name` like '전라남도') then 14 when (`dongcode`.`sido_name` like '경상북도') then 15 when (`dongcode`.`sido_name` like '경상남도') then 16 when (`dongcode`.`sido_name` like '제주특별자치도') then 17 end) AS `id`,`dongcode`.`sido_name` AS `sidoName`,`dongcode`.`gugun_name` AS `gugunName` from `dongcode` where ((`dongcode`.`gugun_name` is not null) and (`dongcode`.`dong_code` <> 9999999999)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-24 20:05:49
